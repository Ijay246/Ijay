import pandas as pd

# Load dataset (Excel or CSV)
df = pd.read_csv("raw_data.csv")
# loads your CSV file into a dataframe